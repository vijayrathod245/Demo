jQuery(document).ready(function () {
	jQuery(".chosen-select").chosen({
		no_results_text: "Oops, nothing found!"
	});
});